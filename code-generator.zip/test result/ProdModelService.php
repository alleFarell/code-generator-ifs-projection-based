<?php

namespace App\Services\Warranty\Setup;

use App\Services\BaseService;

class ProdModelService extends BaseService
{
    public function __construct()
    {
    }
}